<?php

namespace App\Http\Controllers;

use App\mybook;
use Illuminate\Http\Request;

class MybookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('book.books');
    }
    public function sample()
    {
      return view('welcome');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $mybook=new mybook([
    'title'=>$request->get('title'),
    'body'=>$request->get('body'),
  ]);

$mybook->save();
return redirect('/book/create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\mybook  $mybook
     * @return \Illuminate\Http\Response
     */
    public function show(mybook $mybook)
    {
      //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\mybook  $mybook
     * @return \Illuminate\Http\Response
     */
    public function edit(mybook $mybook)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\mybook  $mybook
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, mybook $mybook)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\mybook  $mybook
     * @return \Illuminate\Http\Response
     */
    public function destroy(mybook $mybook)
    {
        //
    }
}
?>
