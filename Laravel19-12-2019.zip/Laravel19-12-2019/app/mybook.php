<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mybook extends Model
{
   public $fillable=[
     'title',
     'body',
   ];
}
