<html>
<head>
</head>
<body>
  <div>
  <a href="/index">Index</a>
  <a href="/about">About</a>
  <a href="/services">Services</a>
</div>
  <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
