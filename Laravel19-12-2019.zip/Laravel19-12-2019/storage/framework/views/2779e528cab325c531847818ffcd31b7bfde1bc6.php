 <?php $__env->startSection('content'); ?>
<br>
Index
<h1><?php echo e($name); ?></h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>