 <?php $__env->startSection('content'); ?>
<br>
About
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>