@extends('layouts.myapp')
 @section('content')
<br>
Index
<h1>{{$name}}</h1>
@endsection
