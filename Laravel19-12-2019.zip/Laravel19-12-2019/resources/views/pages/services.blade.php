@extends('layouts.myapp')
 @section('content')
<br>
Services
@endsection
