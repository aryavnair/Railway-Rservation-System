
<form method="post" action="{{route('book.store')}}" >
  @csrf
  <title></title>
    Title
    <input type="text" name="title"/>
    <br>
    Body
    <input type="text" name="body"/>
    <br>
    <button type="submit" name="Sub">Add</button>
    <br>
</form>
