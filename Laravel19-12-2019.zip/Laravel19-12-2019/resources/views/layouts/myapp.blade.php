<html>
<head>
</head>
<body>
  <div>
  <a href="/index">Index</a>
  <a href="/about">About</a>
  <a href="/services">Services</a>
</div>
  @yield('content')
</body>
</html>
